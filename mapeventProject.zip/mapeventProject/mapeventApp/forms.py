from mapeventApp.eventsform.addevent import  AddEventForm
from mapeventApp.eventsform.userlogin import  UserCreateForm

AddEventForm
UserCreateForm
