from django.shortcuts import redirect, render
from django.core.paginator import  Paginator
from IDZapk.models import  UserRegistration,UserLogin
from django.contrib.auth.views import PasswordChangeView
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib import messages
import re
from django.contrib.auth.models import User
from django.contrib.auth import logout
from django.contrib.auth import authenticate, login
from django.urls import reverse_lazy
from .forms import UserCreateForm
from django.views.generic.edit import CreateView,FormView
from django.views.generic import ListView,DetailView
from django.contrib.messages.views import  SuccessMessageMixin
import requests
from django.views.generic.base import TemplateView
# Create your views here.

class UserCreate(SuccessMessageMixin,CreateView):

		model = UserRegistration
		template_name = 'registration/registration.html'
		form_class = UserCreateForm
		success_url = reverse_lazy('usersdetail')
		success_message = "%(first_name)s %(last_name)s"
		
	
class UsersDetail(ListView):
	
	model = UserRegistration
	template_name = 'usersdetail.html'
	ordering = ['-date_created']
	paginate_by = 3
		
class JsonData(TemplateView):
	template_name = 'jsondata.html'
	r = requests.get('http://aamras.com/dummy/EmployeeDetails.json')
	json_data = r.json()
	extra_context = {'json_data':json_data}

def jsondetail(request,name):
	r = requests.get('http://aamras.com/dummy/EmployeeDetails.json')
	json_data = r.json()
	for i in json_data['employees']:
		if i['name'] == name:
			context = i
	return render(request,'jsondetail.html',{'jsondetail':context})

#class JsonDetail(TemplateView):
#	def get_context_data(self, *args,**kwargs):
#	       context = super(JsonDetail, self).get_context_data(*args,**kwargs)
#	       r = requests.get('http://aamras.com/dummy/EmployeeDetails.json')
#	       json_data = r.json()
#	       for i in json_data['employees']:
#	       	if i['name'] == kwargs['name']:
#	       		context = i
#	       return context

class changePassword(PasswordChangeView):
	form_class = PasswordChangeForm
	success_url = reverse_lazy('password_success')

def password_success(request):
	messages.info(request,"Password Changed Successfully")
	return render (request, 'personalDetails.html')

