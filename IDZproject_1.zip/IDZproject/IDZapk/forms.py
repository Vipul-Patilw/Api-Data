from IDZapk.registerationforms.userlogin import  UserCreateForm
from IDZapk.registerationforms.userupdate import  UserUpdateForm
from IDZapk.Apiforms.add_data_to_api import  AddDataInApi

UserCreateForm
UserUpdateForm
AddDataInApi
