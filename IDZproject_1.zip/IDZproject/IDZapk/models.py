from django.db import models
from django.contrib.auth.models import User
import datetime
# Create your models here.
class UserRegistration(models.Model):
	
	first_name = models.CharField(max_length=122)
	
	last_name = models.CharField(max_length=122)
	
	mobile_number= models.CharField(max_length=100)
		
	email= models.CharField(max_length=122)
	
	birthdate = models.DateField()
	
	date_created = models.DateTimeField(auto_now_add=True)


	def __str__(self):
		return self.first_name 


class UserLogin(models.Model):
	username  = models.CharField(max_length=122)
	Loginpassword = models.CharField(max_length=122)
	def __str__(self):
		return self.username

class ChangePassword(models.Model):
		old_password = models.CharField(max_length=122)
		new_password1= models.CharField(max_length=122)
		newpassword2 = models.CharField(max_length=122)


