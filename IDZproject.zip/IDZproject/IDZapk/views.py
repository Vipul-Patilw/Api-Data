from django.shortcuts import redirect, render
from django.core.paginator import  Paginator
from IDZapk.models import  UserRegistration,UserLogin
from django.contrib.auth.views import PasswordChangeView
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib import messages
import re
from django.contrib.auth.models import User

from django.contrib.auth import logout
from django.contrib.auth import authenticate, login
from django.urls import reverse_lazy
from .forms import UserCreateForm
from django.views.generic.edit import CreateView,FormView
from django.views.generic import ListView,DetailView
from django.contrib.messages.views import  SuccessMessageMixin
import requests
from django.views.generic.base import TemplateView
from django.contrib.auth.mixins import  LoginRequiredMixin
# Create your views here.

class UserCreate(SuccessMessageMixin,CreateView):

		model = UserRegistration
		template_name = 'registration/registration.html'
		form_class = UserCreateForm
		success_url = reverse_lazy('usersdetail')
		success_message = "%(first_name)s %(last_name)s"
		def form_valid(self, form):
		      		 email = form.cleaned_data['email']
		      		 password= form.cleaned_data['password']
		      		 myuser = User.objects.create_user(email,email,password)
		      		 myuser.save()
		      		 return super(UserCreate, self).form_valid(form)
		
	
class UsersDetail(ListView):
	
	model = UserRegistration
	template_name = 'usersdetail.html'
	ordering = ['-date_created']
	paginate_by = 3

	
class JsonData(LoginRequiredMixin,TemplateView):
	template_name = 'jsondata.html'
	r = requests.get('http://aamras.com/dummy/EmployeeDetails.json')
	json_data = r.json()
	extra_context = {'json_data':json_data}

#def jsondetail(request,name):
#	r = requests.get('http://aamras.com/dummy/EmployeeDetails.json')
#	json_data = r.json()
#	for i in json_data['employees']:
#		if i['name'] == name:
#			context = i
#	return render(request,'jsondetail.html',{'jsondetail':context})

class JsonDetail(LoginRequiredMixin,TemplateView):
	template_name = 'jsondetail.html'
	def get_context_data(self, *args,**kwargs):
	       context = super(JsonDetail, self).get_context_data(*args,**kwargs)
	       r = requests.get('http://aamras.com/dummy/EmployeeDetails.json')
	       json_data = r.json()
	       for i in json_data['employees']:
	       	if i['name'] == kwargs['name']:
	       		context = i
	       return {'jsondetail':context}

class changePassword(PasswordChangeView):
	form_class = PasswordChangeForm
	success_url = reverse_lazy('password_success')

def password_success(request):
	messages.info(request,"Password Changed Successfully")
	return render (request, 'personalDetails.html')

